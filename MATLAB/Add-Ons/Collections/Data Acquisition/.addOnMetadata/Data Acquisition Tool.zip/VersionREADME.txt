This zip file contains the installers for 2 versions of the Data Acquisition Tool:
1. Data Acquisition Tool.mlappinstall
2. preR2014b Data Acquisition.mlappinstall

The version labeled, "Data Acquisition Tool," only works on R2014b and newer.
The version labeled, "preR2014b Data Acquisition," works on R2013b to R2014b.